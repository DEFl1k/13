﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Collections;

namespace pr13
{
    internal class Program
    {
        static void Main(string[] args)
        {
            try
            {
                ArrayList list = new ArrayList();
                ArrayList list1 = new ArrayList();
                list.Add(4.5);
                list.Add(18);
                list.AddRange(new string[] { "Студент", "Петров" });
                Console.WriteLine("Сколько будет строк?");
                int x = int.Parse(Console.ReadLine());
                Console.WriteLine("Введите индекс, с которого будет вставлен лист");
                int n1 = int.Parse(Console.ReadLine());
                if (x > 0 && n1 > 0)
                {
                    for (int i = 0; i < x; i++)
                    {
                        Console.WriteLine($"Введите {i + 1} строку");
                        list1.Add(Console.ReadLine());
                    }
                    Console.WriteLine();
                    list.InsertRange(n1-1, list1);
                    for (int i = 0; i < list.Count; i++)
                    {
                        Console.WriteLine(list[i]);
                    }
                    Console.WriteLine("Сколько элементов вы хотите удалить?");
                    int z = int.Parse(Console.ReadLine());
                    Console.WriteLine("С какого элемента вы хотите удалить?");
                    int v = int.Parse(Console.ReadLine());
                    if (v > 0)
                    {
                        if (list.Count - v - z >= 0)
                        {
                            list.RemoveRange(v-1, z);
                            Console.WriteLine();
                            foreach (object e in list)
                            {
                                Console.WriteLine(e);
                            }
                        }
                    }
                }
            }
            catch { Console.WriteLine("Неверное значение"); }
            Console.ReadKey();
        }
    }
}
